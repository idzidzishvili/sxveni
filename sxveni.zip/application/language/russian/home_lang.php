<?php
$lang['ADDRESS'] = 'Адрес';
$lang['PHONE'] = 'Телефон';
$lang['CONTACT_US'] = 'Напишите нам';
$lang['NAME'] = 'Имя, фамилия';
$lang['EMAIL'] = 'Электронная почта';
$lang['MESSAGE'] = 'Сообщение';
$lang['SEND_MESSAGE'] = 'Отправить сообщение';
$lang['VISIT_WEBSITE'] = 'Перейти на сайт';
$lang['NOT_FOUND'] = 'Страница, которую вы ищете, не найдена';
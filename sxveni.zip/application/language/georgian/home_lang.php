<?php
$lang['ADDRESS'] = 'მისამართი';
$lang['PHONE'] = 'ტელეფონი';
$lang['CONTACT_US'] = 'დაგვიკავშირდით';
$lang['NAME'] = 'სახელი, გვარი';
$lang['EMAIL'] = 'Email';
$lang['MESSAGE'] = 'შეტყობინება';
$lang['SEND_MESSAGE'] = 'შეტყობინების გაგზავნა';
$lang['VISIT_WEBSITE'] = 'საიტზე გადასვლა';
$lang['NOT_FOUND'] = 'გვერდი, რომელსაც ეძებთ ვერ მოიძებნა';
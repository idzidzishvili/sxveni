<?php
$lang['ADDRESS'] = 'Address';
$lang['PHONE'] = 'Phone';
$lang['CONTACT_US'] = 'Contact us';
$lang['NAME'] = 'Firstname, Lastname';
$lang['EMAIL'] = 'Email';
$lang['MESSAGE'] = 'Message';
$lang['SEND_MESSAGE'] = 'Send message';
$lang['VISIT_WEBSITE'] = 'Go to website';
$lang['NOT_FOUND'] = 'The page you requested could not be found';
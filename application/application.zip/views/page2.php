<li class="nav-item" data-aos="flip-left" data-aos-delay="200">
   <a href="#section-3">
      <div class="nav-card">
         <span class="sxveni-audio"></span>
         <h3>აუდიო</h3>
         <div class="card-text">
            ცნობილი ფაქტია, რომ გვერდის წაკითხვად შიგთავსს შეუძლია მკითხველის ყურადღება მიიზიდოს და დიზაინის აღქმაში ხელი შეუშალოს. Lorem Ipsum-ის გამოყენებით ვღებულობთ იმაზე მეტ-ნაკლებად სწორი გადანაწილების ტექსტს, ვიდრე ერთიდაიგივე გამეორებადი სიტყვებია ხოლმე.
         </div>
      </div>
   </a>
</li>
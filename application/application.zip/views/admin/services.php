<?php $this->load->view('admin/templates/header');?>


<div class="container-fluid">
   <div class="row">
      <?php $this->load->view('admin/templates/leftnav');?>

      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
         <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2"><?php echo $currentService->name_ge;?></h1>
         </div>

         <?php echo form_open_multipart(base_url('admin/processUpload/'.$page));?>

            <div class="form-group row mb-2">
               <label for="getext" class="col-sm-2 col-form-label">ქართული ტექსტი</label>
               <div class="col-sm-10">
                  <textarea class="form-control" id="getext" name="getext" value=""><?php echo $currentService->text_ge;?></textarea>
                  <small style="color:red"><?php echo form_error('getext'); ?></small>
               </div>
            </div>

            <div class="form-group row mb-2">
               <label for="entext" class="col-sm-2 col-form-label">ინგლისური ტექსტი</label>
               <div class="col-sm-10">
                  <textarea class="form-control" id="entext" name="entext" value=""><?php echo $currentService->text_en;?></textarea>
                  <small style="color:red"><?php echo form_error('entext'); ?></small>
               </div>
            </div>

            <div class="form-group row mb-2">
               <label for="rutext" class="col-sm-2 col-form-label">რუსული ტექსტი</label>
               <div class="col-sm-10">
                  <textarea class="form-control" id="rutext" name="rutext" value=""><?php echo $currentService->text_ru;?></textarea>
                  <small style="color:red"><?php echo form_error('rutext'); ?></small>
               </div>
            </div>
            
            <div class="form-group row mb-2">
               <label for="image-1" class="col-sm-2 col-form-label">ფაილები</label>
               <div class="col-sm-10">
                  <div class="row">

                     <?php for($i=0; $i<4; $i++): ?>
                        <div class="col-sm-6 col-md-4 col-lg-3">
                           <label for="imagename<?php echo $i; ?>" title="შეცვლა">
                              <div class="imgframe">
                                 <?php
                                    $image = 'noimage.jpg';
                                    $fileToShow = $currentService->{'file'. ($i + 1)};
                                    if (!$fileToShow)
                                       $image = 'noimage.jpg';
                                    else if (substr($fileToShow,-3,3)=='avi'||substr($fileToShow,-3,3)=='mp4'||substr($fileToShow,-3,3)=='mpg'||substr($fileToShow,-4,4)=='mpeg')
                                       $image = 'video.jpg';
                                    else if (substr($fileToShow,-3,3)=='jpg'||substr($fileToShow,-4,4)=='jpeg'||substr($fileToShow,-3,3)=='png')
                                       $image = $fileToShow;
                                    else if (substr($fileToShow,-3,3)=='mp3'||substr($fileToShow,-3,3)=='vaw')
                                       $image = 'audio.jpg';
                                 ?>
                                 <img src="<?=  base_url('assets/uploads/'.$image);?>" class="rounded mx-auto d-block" id="previewImg<?php echo $i; ?>">
                              </div>
                           </label>
                           <input type="file" name="image_upload<?php echo $i; ?>" class="image_upload" id="imagename<?php echo $i; ?>" style="display:none" 
                              onchange="previewFile(this, <?php echo $i; ?>, 'previewImg<?php echo $i; ?>');" />
                           <input type="hidden" name="filename<?php echo $i; ?>" class="filename" value="">
                           <input type="hidden" name="imgname<?php echo $i; ?>" value="imagename<?php echo $i; ?>">
                           <input type="hidden" name="fileid<?php echo $i; ?><?php echo $i; ?>" class="fileid" value="<?php echo $i; ?>">
                        </div>
                     <?php endfor; ?>
                  </div>                     
               </div>
            </div>
            <div class="form-group row mt-4">
               <div class="col-sm-10 offset-sm-2">
                  <button type="submit" class="btn btn-success">შენახვა</button>
               </div>
            </div>
         <?php echo form_close(); ?>
      </main>
   </div>
</div>

<script type="text/javascript">
   function previewFile(input, n, imgtag){
      var file = $("input[type=file]").get(n).files[0];
      console.log(file.name);
      if(file.name.toLowerCase().endsWith("jpg")||file.name.toLowerCase().endsWith("jpeg")||file.name.toLowerCase().endsWith("png")){         
         var reader = new FileReader(); 
         reader.onload = function(){
            $("#"+imgtag).attr("src", reader.result);
         } 
         reader.readAsDataURL(file);
      }else if(file.name.toLowerCase().endsWith("mp3")||file.name.toLowerCase().endsWith("vaw")){
         $("#"+imgtag).attr("src", '../../assets/uploads/audio.jpg');
      }
      else if(file.name.toLowerCase().endsWith("mp4")||file.name.toLowerCase().endsWith("avi")||file.name.toLowerCase().endsWith("mpg")||file.name.toLowerCase().endsWith("mpeg")){
         $("#"+imgtag).attr("src", '../../assets/uploads/video.jpg');
      }
   }

   $('.image_upload').change(function(e) {
		var fileName = e.target.files[0].name;		
		$(this).siblings('input.filename').val(fileName);		
   });
   
</script>

<?php $this->load->view('admin/templates/footer');?>
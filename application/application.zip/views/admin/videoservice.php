<?php $this->load->view('admin/templates/header');?>


<div class="container-fluid">
   <div class="row">
      <?php $this->load->view('admin/templates/leftnav');?>

      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
         <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2"><?php echo $currentService->name_ge;?></h1>
         </div>

         <?php echo form_open_multipart(base_url('admin/processVideoService/'.$page));?>

            <div class="form-group row mb-2">
               <label for="getext" class="col-sm-2 col-form-label">ქართული ტექსტი</label>
               <div class="col-sm-10">
                  <textarea class="form-control" id="getext" name="getext" value=""><?php echo $currentService->text_ge;?></textarea>
                  <small style="color:red"><?php echo form_error('getext'); ?></small>
               </div>
            </div>

            <div class="form-group row mb-2">
               <label for="entext" class="col-sm-2 col-form-label">ინგლისური ტექსტი</label>
               <div class="col-sm-10">
                  <textarea class="form-control" id="entext" name="entext" value=""><?php echo $currentService->text_en;?></textarea>
                  <small style="color:red"><?php echo form_error('entext'); ?></small>
               </div>
            </div>

            <div class="form-group row mb-2">
               <label for="rutext" class="col-sm-2 col-form-label">რუსული ტექსტი</label>
               <div class="col-sm-10">
                  <textarea class="form-control" id="rutext" name="rutext" value=""><?php echo $currentService->text_ru;?></textarea>
                  <small style="color:red"><?php echo form_error('rutext'); ?></small>
               </div>
            </div>

            <div class="form-group row mb-2">
               <label class="col-sm-2 col-form-label">ვიდეო ლინკი 1</label>
               <div class="col-sm-3">
                  <input class="form-control form-control-sm" id="video1name" name="video1name" value="<?php echo $currentService->img1;?>" readonly>
                  <small style="color:red"><?php echo form_error('video1name'); ?></small>
               </div>
               <div class="col-sm-3">
                  <input type="file" class="form-control form-control-sm" id="video1" name="video1">
                  <small style="color:red"><?php echo form_error('video1'); ?></small>
               </div>
               <div class="col-sm-4">
                  <input class="form-control form-control-sm" id="videolink1" name="videolink1" value="<?php echo $page<>8 ? 'https://www.youtube.com/watch?v='.$currentService->file1:$currentService->file1;?>" placeholder="https://www.youtube.com/watch?v=aBcdeFGHiJk">
                  <small style="color:red"><?php echo form_error('videolink1'); ?></small>
               </div>
            </div>
            <div class="form-group row mb-2">
               <label class="col-sm-2 col-form-label">ვიდეო ლინკი 2</label>
               <div class="col-sm-3">
                  <input class="form-control form-control-sm" id="video2name" name="video2name" value="<?php echo $currentService->img2;?>" readonly>
                  <small style="color:red"><?php echo form_error('video2name'); ?></small>
               </div>
               <div class="col-sm-3">
                  <input type="file" class="form-control form-control-sm" id="video2" name="video2">
                  <small style="color:red"><?php echo form_error('video2'); ?></small>
               </div>
               <div class="col-sm-4">
                  <input class="form-control form-control-sm" id="videolink2" name="videolink2" value="<?php echo $page<>8 ? 'https://www.youtube.com/watch?v='.$currentService->file2:$currentService->file2;?>" placeholder="https://www.youtube.com/watch?v=aBcdeFGHiJk">
                  <small style="color:red"><?php echo form_error('videolink2'); ?></small>
               </div>
            </div>
            <div class="form-group row mb-2">
               <label class="col-sm-2 col-form-label">ვიდეო ლინკი 3</label>
               <div class="col-sm-3">
                  <input class="form-control form-control-sm" id="video3name" name="video3name" value="<?php echo $currentService->img3;?>" readonly>
                  <small style="color:red"><?php echo form_error('video3name'); ?></small>
               </div>
               <div class="col-sm-3">
                  <input type="file" class="form-control form-control-sm" id="video3" name="video3">
                  <small style="color:red"><?php echo form_error('video3'); ?></small>
               </div>
               <div class="col-sm-4">
                  <input class="form-control form-control-sm" id="videolink3" name="videolink3" value="<?php echo $page<>8 ? 'https://www.youtube.com/watch?v='.$currentService->file3:$currentService->file3;?>" placeholder="https://www.youtube.com/watch?v=aBcdeFGHiJk">
                  <small style="color:red"><?php echo form_error('videolink3'); ?></small>
               </div>
            </div>
            <div class="form-group row mb-2">
               <label class="col-sm-2 col-form-label">ვიდეო ლინკი 4</label>
               <div class="col-sm-3">
                  <input class="form-control form-control-sm" id="video4name" name="video4name" value="<?php echo $currentService->img4;?>" readonly>
                  <small style="color:red"><?php echo form_error('video4name'); ?></small>
               </div>
               <div class="col-sm-3">
                  <input type="file" class="form-control form-control-sm" id="video4" name="video4">
                  <small style="color:red"><?php echo form_error('video4'); ?></small>
               </div>
               <div class="col-sm-4">
                  <input class="form-control form-control-sm" id="videolink4" name="videolink4" value="<?php echo $page<>8 ? 'https://www.youtube.com/watch?v='.$currentService->file4:$currentService->file4;?>" placeholder="https://www.youtube.com/watch?v=aBcdeFGHiJk">
                  <small style="color:red"><?php echo form_error('videolink4'); ?></small>
               </div>
            </div>
            
            <div class="form-group row mt-4">
               <div class="col-sm-10 offset-sm-2">
                  <button type="submit" class="btn btn-success">შენახვა</button>
               </div>
            </div>
         <?php echo form_close(); ?>
      </main>
   </div>
</div>


<?php $this->load->view('admin/templates/footer');?>
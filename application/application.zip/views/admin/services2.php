<?php $this->load->view('admin/templates/header');?>


<div class="container-fluid">
   <div class="row">
      <?php $this->load->view('admin/templates/leftnav');?>

      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
         <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2"><?php echo $currentService->name_ge;?></h1>
         </div>

         <?php echo form_open_multipart(base_url('admin/processUpload/'.$page));?>

            <div class="form-group row mb-2">
               <label for="getext" class="col-sm-2 col-form-label">ქართული ტექსტი</label>
               <div class="col-sm-10">
                  <textarea class="form-control" id="getext" name="getext" value=""><?php echo $currentService->text_ge;?></textarea>
                  <small style="color:red"><?php echo form_error('getext'); ?></small>
               </div>
            </div>

            <div class="form-group row mb-2">
               <label for="entext" class="col-sm-2 col-form-label">ინგლისური ტექსტი</label>
               <div class="col-sm-10">
                  <textarea class="form-control" id="entext" name="entext" value=""><?php echo $currentService->text_en;?></textarea>
                  <small style="color:red"><?php echo form_error('entext'); ?></small>
               </div>
            </div>

            <div class="form-group row mb-2">
               <label for="rutext" class="col-sm-2 col-form-label">რუსული ტექსტი</label>
               <div class="col-sm-10">
                  <textarea class="form-control" id="rutext" name="rutext" value=""><?php echo $currentService->text_ru;?></textarea>
                  <small style="color:red"><?php echo form_error('rutext'); ?></small>
               </div>
            </div>
            
            <div class="form-group row mb-2">
               <label for="image-1" class="col-sm-2 col-form-label">ფაილები</label>
               <div class="col-sm-10">
                  <div class="form-group row">
                     
                     <div class="table-responsive">
                        <table class="table table-sm">
                           <thead>
                              <tr>
                                 <th>#</th>
                                 <th>ფაილის სახელი</th>
                                 <th>ალბომის N</th>
                                 <th width="80px">მოქმედება</th>
                              </tr>
                           </thead>
                           <tbody id="media">
                              <?php foreach($albumData as $index=>$albumdata): ?>
                              <tr>
                                 <td><?php echo $index+1;?></td>
                                 <td><?php echo $albumdata->originalname; ?></td>
                                 <td><?php echo $albumdata->albumid; ?></td>
                                 <td><a href="<?php echo base_url('admin/deletealbumitem/'.$albumdata->id.'/'.$page);?>"><button class="btn btn-danger btn-sm">Delete</button></td>
                              </tr>
                              <?php endforeach; ?>
                              <?php if(!$albumData): ?>
                                 <td colspan="4"><strong style="color:red"> ამ კატეგორიაში ფაილები არ არის </strong></td> 
                              <?php endif; ?>                           
                              <tr><!-- Add button -->
                                 <td colspan="4"><button type="button" class="btn btn-primary btn-sm col-2 my-2" onclick="addField()">+ დამატება</button></td>                                
                              </tr><!-- file and category fields -->
                              <tr>
                                 <td></td>
                                 <td>
                                    <input type="file" name="file_upload[]" class="form-control form-control-sm" multiple />
                                 </td>
                                 <td>
                                    <select name="album_category[]" class="form-control form-control-sm">
                                       <option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option>
                                    </select>
                                 </td>
                                 <td></td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>

            <div class="form-group row mt-4">
               <div class="col-sm-10 offset-sm-2">
                  <button type="submit" class="btn btn-success">შენახვა</button>
               </div>
            </div>

         <?php echo form_close(); ?>
      </main>
   </div>
</div>

<script type="text/javascript">
   function addField(){
      //$("#media").append('<div class="col-xs-6"><input type="file" name="file_upload[]" class="form-control" /></div><div class="col-xs-6"><select name="album_category[]" class="form-control"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option></select></div>');
      $("#media").append('<tr><td></td><td><input type="file" name="file_upload[]" class="form-control form-control-sm" multiple /></td><td><select name="album_category[]" class="form-control form-control-sm"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option></select></td><td></td></tr>');
   }   
</script>

<?php $this->load->view('admin/templates/footer');?>